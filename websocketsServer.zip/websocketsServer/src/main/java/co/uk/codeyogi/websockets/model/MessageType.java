package co.uk.codeyogi.websockets.model;

public enum MessageType {
    CHAT,CONNECT,DISCONNECT;
}

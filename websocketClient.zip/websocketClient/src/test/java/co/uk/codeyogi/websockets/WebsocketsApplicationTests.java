package co.uk.codeyogi.websockets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsocketsApplicationTests {

	@Test
	void contextLoads() {
	}

}

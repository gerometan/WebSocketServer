package co.uk.codeyogi.websockets.rest;

public enum MessageType {
    CHAT,CONNECT,DISCONNECT;
}

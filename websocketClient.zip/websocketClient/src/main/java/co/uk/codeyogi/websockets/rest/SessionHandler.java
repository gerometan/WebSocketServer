package co.uk.codeyogi.websockets.rest;

import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.stomp.*;

import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


@Slf4j
public class SessionHandler implements StompSessionHandler {
    @Override
    public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
        log.info("Connected");
        session.subscribe("/topic/public", this);

        ChatMessage message = ChatMessage.builder()
                .type(MessageType.CHAT)
                .content("hello")
                .sender("me")
                .time(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE))
                .build();

        session.send("/app/chat.send", message);

    }

    @Override
    public void handleException(StompSession session, StompCommand command, StompHeaders headers, byte[] payload, Throwable exception) {

    }

    @Override
    public void handleTransportError(StompSession session, Throwable exception) {

    }

    @Override
    public Type getPayloadType(StompHeaders headers) {
        return null;
    }

    @Override
    public void handleFrame(StompHeaders headers, Object payload) {

    }
}
